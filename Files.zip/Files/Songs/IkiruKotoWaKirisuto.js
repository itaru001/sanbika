

function Jissou(uta) {
	
	var chord1 = document.getElementById("chord1");
	chord1.innerHTML = uta.getSharpD();

	var chord2 = document.getElementById("chord2");
	chord2.innerHTML = uta.getSharpG();

	var chord3 = document.getElementById("chord3");
	chord3.innerHTML = uta.getSharpA();

	var chord4 = document.getElementById("chord4");
	chord4.innerHTML = uta.getSharpD();

	var chord5 = document.getElementById("chord5");
	chord5.innerHTML = uta.getSharpD();

	var chord6 = document.getElementById("chord6");
	chord6.innerHTML = uta.getSharpG();

	var chord7 = document.getElementById("chord7");
	chord7.innerHTML = uta.getSharpA();

	var chord8 = document.getElementById("chord8");
	chord8.innerHTML = uta.getSharpB() + "m";

	var chord9 = document.getElementById("chord9");
	chord9.innerHTML = uta.getSharpG();

	var chord10 = document.getElementById("chord10");
	chord10.innerHTML = uta.getSharpA();

	var chord11 = document.getElementById("chord11");
	chord11.innerHTML = uta.getSharpD();

	var chord12 = document.getElementById("chord12");
	chord12.innerHTML = uta.getSharpE() + "m";

	var chord13 = document.getElementById("chord13");
	chord13.innerHTML = uta.getSharpA();

	var chord14 = document.getElementById("chord14");
	chord14.innerHTML = uta.getSharpD();


}


























