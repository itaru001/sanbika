


function Jissou(uta) {


	// Verse 1
	var chord1 = document.getElementById("chord1");
	chord1.innerHTML = uta.getSharpG();

	var chord2 = document.getElementById("chord2");
	chord2.innerHTML = uta.getSharpE() + "m";

	var chord3 = document.getElementById("chord3");
	chord3.innerHTML = uta.getSharpC();

	var chord4 = document.getElementById("chord4");
	chord4.innerHTML = uta.getSharpD();

	var chord5 = document.getElementById("chord5");
	chord5.innerHTML = uta.getSharpG();

	var chord6 = document.getElementById("chord6");
	chord6.innerHTML = uta.getSharpE() + "m";

	var chord7 = document.getElementById("chord7");
	chord7.innerHTML = uta.getSharpC();

	var chord8 = document.getElementById("chord8");
	chord8.innerHTML = uta.getSharpD();

	// サビ
	var chord9 = document.getElementById("chord9");
	chord9.innerHTML = uta.getSharpG();

	var chord10 = document.getElementById("chord10");
	chord10.innerHTML = uta.getSharpE() + "m";

	var chord11 = document.getElementById("chord11");
	chord11.innerHTML = uta.getSharpC();

	var chord12 = document.getElementById("chord12");
	chord12.innerHTML = uta.getSharpG();

	var chord13 = document.getElementById("chord13");
	chord13.innerHTML = uta.getSharpA() + "m";

	var chord14 = document.getElementById("chord14");
	chord14.innerHTML = uta.getSharpD();

	var chord15 = document.getElementById("chord15");
	chord15.innerHTML = uta.getSharpG();

	var chord16 = document.getElementById("chord16");
	chord16.innerHTML = uta.getSharpE() + "m";

	var chord17 = document.getElementById("chord17");
	chord17.innerHTML = uta.getSharpC();

	var chord18 = document.getElementById("chord18");
	chord18.innerHTML = uta.getSharpG();

	var chord19 = document.getElementById("chord19");
	chord19.innerHTML = uta.getSharpA() + "m";

	var chord20 = document.getElementById("chord20");
	chord20.innerHTML = uta.getSharpD();

	var chord21 = document.getElementById("chord21");
	chord21.innerHTML = uta.getSharpG();

}

















