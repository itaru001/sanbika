

function Jissou(uta) {

	var chord1 = document.getElementById("chord1");
	chord1.innerHTML = uta.getSharpC();

	var chord2 = document.getElementById("chord2");
	chord2.innerHTML = uta.getSharpG() + "/" + uta.getSharpB();

	var chord3 = document.getElementById("chord3");
	chord3.innerHTML = uta.getSharpA() + "m";

	var chord4 = document.getElementById("chord4");
	chord4.innerHTML = uta.getSharpF();

	var chord5 = document.getElementById("chord5");
	chord5.innerHTML = uta.getSharpD() + "m";

	var chord6 = document.getElementById("chord6");
	chord6.innerHTML = uta.getSharpC() + "/" + uta.getSharpE();

	var chord7 = document.getElementById("chord7");
	chord7.innerHTML = uta.getSharpF();

	var chord8 = document.getElementById("chord8");
	chord8.innerHTML = uta.getSharpG() + "sus4";

	var chord9 = document.getElementById("chord9");
	chord9.innerHTML = uta.getSharpG();

	var chord10 = document.getElementById("chord10");
	chord10.innerHTML = uta.getSharpC();

	var chord11 = document.getElementById("chord11");
	chord11.innerHTML = uta.getSharpG() + "/" + uta.getSharpB();

	var chord12 = document.getElementById("chord12");
	chord12.innerHTML = uta.getSharpA() + "m";

	var chord13 = document.getElementById("chord13");
	chord13.innerHTML = uta.getSharpF();

	var chord14 = document.getElementById("chord14");
	chord14.innerHTML = uta.getSharpD() + "m";

	var chord15 = document.getElementById("chord15");
	chord15.innerHTML = uta.getSharpC() + "/" + uta.getSharpE();

	var chord16 = document.getElementById("chord16");
	chord16.innerHTML = uta.getSharpF();

	var chord17 = document.getElementById("chord17");
	chord17.innerHTML = uta.getSharpG() + "sus4";

	var chord18 = document.getElementById("chord18");
	chord18.innerHTML = uta.getSharpC();


	

	// サビ
	var chord19 = document.getElementById("chord19");
	chord19.innerHTML = uta.getSharpF();

	var chord20 = document.getElementById("chord20");
	chord20.innerHTML = uta.getSharpG();

	var chord21 = document.getElementById("chord21");
	chord21.innerHTML = uta.getSharpC();

	var chord22 = document.getElementById("chord22");
	chord22.innerHTML = uta.getSharpF();

	var chord23 = document.getElementById("chord23");
	chord23.innerHTML = uta.getSharpG();

	var chord24 = document.getElementById("chord24");
	chord24.innerHTML = uta.getSharpA() + "m";

	var chord25 = document.getElementById("chord25");
	chord25.innerHTML = uta.getSharpF();

	var chord26 = document.getElementById("chord26");
	chord26.innerHTML = uta.getSharpG();

	var chord27 = document.getElementById("chord27");
	chord27.innerHTML = uta.getSharpC();

	var chord28 = document.getElementById("chord28");
	chord28.innerHTML = uta.getSharpA() + "m";

	var chord29 = document.getElementById("chord29");
	chord29.innerHTML = uta.getSharpD() + "m";

	var chord30 = document.getElementById("chord30");
	chord30.innerHTML = uta.getSharpG();

	var chord31 = document.getElementById("chord31");
	chord31 = uta.getSharpC();

}





















